import React, { useState } from 'react';

function Pending() {
  
  return (
    <div>
      <h3>I am Pending</h3>
    </div>
  );
}

export default Pending;