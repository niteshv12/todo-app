import React, { useState } from 'react';

function Complete() {
  
  return (
    <div>
      <h3>I am complete</h3>
    </div>
  );
}

export default Complete;